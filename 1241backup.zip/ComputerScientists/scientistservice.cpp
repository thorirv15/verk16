#include "scientistservice.h"

ScientistService::ScientistService()
{

}

//1.Fall sem lætur dataaccess ná í einhverjar upplýsingar úr skránni
//2.
