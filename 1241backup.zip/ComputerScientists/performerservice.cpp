#include "performerservice.h"

PerformerService::PerformerService()
{

}

//1.Fall sem lætur dataaccess ná í einhverjar upplýsingar úr skránni
//2.
