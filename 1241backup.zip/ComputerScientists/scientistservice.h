#ifndef SCIENTISTSERVICE_H
#define SCIENTISTSERVICE_H
#include <string>
#include <vector>
using namespace std;


class ScientistService
{
public:
    ScientistService();

    int findScientist(string name)
    {


    }





private:

};

#endif // SCIENTISTSERVICE_H
