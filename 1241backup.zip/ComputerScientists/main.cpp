#include "consoleui.h"

int main()
{
    ConsoleUI ui;

    ui.run();

    return 0;
}
